package com.example.tarea4_davidramosdelpino;

import java.util.ArrayList;

public class ListaContactos {
    public static ArrayList<Contacto> contactos=new ArrayList<>();
}
